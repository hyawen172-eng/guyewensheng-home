# 顾夜雯声小家

A quiet place to return.

This repository contains only the static site program. It must not contain API keys, private API endpoints, chat logs, diary entries, memory exports, or personal backup JSON.

## Publish with GitHub Pages

1. Upload the files in this folder to the repository root on branch `main` (including `index.html`, `.nojekyll`, and `.github/workflows/pages.yml`).
2. In GitHub, open **Settings → Pages**.
3. Under **Build and deployment → Source**, select **GitHub Actions**.
4. After the workflow finishes, open: `https://hyawen172-eng.github.io/guyewensheng-home/`

The workflow deploys the static website whenever `main` is updated.

## Preserve local records

The old downloaded `content://` file and the hosted `https://` site use different browser storage origins. Before switching, open the old local file and export the full house backup JSON from the app's backup tools. Import it on the hosted site. Import is intended to merge records, not clear them. Keep the old file and backup until you confirm the restored chats, memories, diaries, photos, and settings.

API key is deliberately not included in backups or source code. Re-enter it in the API settings on the hosted site. The app can store it in this browser's local storage if the device-remember option is enabled. Do not use that option on shared devices.

## Privacy and security

- Do not upload `.env`, API keys, saved API configuration, exported chat/memory data, or private backups.
- The site source is public. Anyone can visit it; browser-local records are not included in the repository.
- The API key is stored locally by the browser app. A static frontend cannot make a key secret from its device/browser; use a private proxy/backend if stronger key protection is needed.
